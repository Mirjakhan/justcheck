// Import the necessary function for preloading images
import { preloadImages, getGrid } from './utils.js';

// Define a variable that will store the Lenis smooth scrolling object
let lenis;

// Function to initialize Lenis for smooth scrolling
const initSmoothScrolling = () => {
	// Instantiate the Lenis object with specified properties
	lenis = new Lenis({
		lerp: 0.1, // Lower values create a smoother scroll effect
		smoothWheel: true // Enables smooth scrolling for mouse wheel events
	});

	// Update ScrollTrigger each time the user scrolls
	lenis.on('scroll', () => ScrollTrigger.update());

	// Define a function to run at each animation frame
	const scrollFn = (time) => {
		lenis.raf(time); // Run Lenis' requestAnimationFrame method
		requestAnimationFrame(scrollFn); // Recursively call scrollFn on each frame
	};
	// Start the animation frame loop
	requestAnimationFrame(scrollFn);
};

// All elements with class .grid
const grids = document.querySelectorAll('.grid');

// Function to apply scroll-triggered animations to a given gallery
const applyAnimation = (grid, animationType) => {
	// Child elements of grid
	const gridWrap = grid.querySelector('.grid-wrap');
	const gridItems = grid.querySelectorAll('.grid__item');
	const gridItemsInner = [...gridItems].map(item => item.querySelector('.grid__item-inner'));
	
	// Define GSAP timeline with ScrollTrigger
	const timeline = gsap.timeline({
	  	defaults: { ease: 'none' },
	  	scrollTrigger: {
			trigger: gridWrap,
			start: 'top bottom+=5%',
			end: 'bottom top-=5%',
			scrub: true
	  	}
	});
	
	// Apply different animations based on type
	switch(animationType) {
		
		case 'type1':

			// Set some CSS related style values
			grid.style.setProperty('--perspective', '1000px');
			grid.style.setProperty('--grid-inner-scale', '0.5');

			timeline
			.set(gridWrap, {
				rotationY: 25
			})
			.set(gridItems, {
				z: () => gsap.utils.random(-1600,200)
			})
			.fromTo(gridItems, {
				xPercent: () => gsap.utils.random(-1000,-500)
			}, {
				xPercent: () => gsap.utils.random(500,1000)
			}, 0)
			.fromTo(gridItemsInner, {
				scale: 2
			}, {
				scale: .5
			}, 0)
			
			break;

	  	case 'type2':
			
			// Set some CSS related style values
			grid.style.setProperty('--grid-width', '160%');
			grid.style.setProperty('--perspective', '2000px');
			grid.style.setProperty('--grid-inner-scale', '0.5');
			grid.style.setProperty('--grid-item-ratio', '0.8');
			grid.style.setProperty('--grid-columns', '6');
			grid.style.setProperty('--grid-gap', '14vw');

		  	timeline
		  	.set(gridWrap, {
				rotationX: 20
			})
			.set(gridItems, {
				z: () => gsap.utils.random(-3000,-1000)
			})
			.fromTo(gridItems, {
				yPercent: () => gsap.utils.random(100,1000),
				rotationY: -45,
				filter: 'brightness(200%)'
			}, {
				ease: 'power2',
				yPercent: () => gsap.utils.random(-1000,-100),
				rotationY: 45,
				filter: 'brightness(0%)'
			}, 0)
			.fromTo(gridWrap, {
				rotationZ: -5,
			}, {
				rotationX: -20,
				rotationZ: 10,
				scale: 1.2
			}, 0)
			.fromTo(gridItemsInner, {
				scale: 2
			}, {
				scale: 0.5
			}, 0)

			break;
	  
		case 'type3':
			
			// Set some CSS related style values
			grid.style.setProperty('--grid-width', '105%');
			grid.style.setProperty('--grid-columns', '8');
			grid.style.setProperty('--perspective', '1500px');
			grid.style.setProperty('--grid-inner-scale', '0.5');
			
			timeline
			.set(gridItems, {
				transformOrigin: '50% 0%',
				z: () => gsap.utils.random(-5000,-2000),
				rotationX: () => gsap.utils.random(-65,-25),
				filter: 'brightness(0%)'
			})	
			.to(gridItems, {
				xPercent: () => gsap.utils.random(-150,150),
				yPercent: () => gsap.utils.random(-300,300),
				rotationX: 0,
				filter: 'brightness(200%)'
			}, 0)
			.to(gridWrap, {
				z: 6500
			}, 0)
			.fromTo(gridItemsInner, {
				scale: 2
			}, {
				scale: 0.5
			}, 0);
			
			break;

		case 'type4':
			
			// Set some CSS related style values
			grid.style.setProperty('--grid-width', '50%');
			grid.style.setProperty('--perspective', '3000px');
			grid.style.setProperty('--grid-item-ratio', '0.8');
			grid.style.setProperty('--grid-columns', '3');
			grid.style.setProperty('--grid-gap', '1vw');

			timeline
			.set(gridWrap, {
				transformOrigin: '0% 50%',
				rotationY: 30,
				xPercent: -75
			})
			.set(gridItems, {
				transformOrigin: '50% 0%'
			})
			.to(gridItems, {
				duration: 0.5,
				ease: 'power2',
				z: 500,
				stagger: 0.04
			}, 0)
			.to(gridItems, {
				duration: 0.5,
				ease: 'power2.in',
				z: 0,
				stagger: 0.04
			}, 0.5)
			.fromTo(gridItems, {
				rotationX: -70,
				filter: 'brightness(120%)'
			}, {
				duration: 1,
				rotationX: 70,
				filter: 'brightness(0%)',
				stagger: 0.04
			}, 0)
			
			break;

		case 'type5':

			// Set some CSS related style values
			grid.style.setProperty('--grid-width', '120%');
			grid.style.setProperty('--grid-columns', '8');
			grid.style.setProperty('--grid-gap', '0');
			
			const gridObj = getGrid(gridItems);

			timeline
			.set(gridWrap, {
				rotationX: 50
			})
			.to(gridWrap, {
				rotationX: 30
			})
			.fromTo(gridItems, {
				filter: 'brightness(0%)'
			}, {
				filter: 'brightness(100%)'
			}, 0)
			.to(gridObj.rows('even'), {
				xPercent: -100,
				ease: 'power1'
			}, 0)
			.to(gridObj.rows('odd'), {
				xPercent: 100,
				ease: 'power1'
			}, 0)
			.addLabel('rowsEnd', '>-=0.15')
			.to(gridItems, {
				ease: 'power1',
				yPercent: () => gsap.utils.random(-100, 200),
			}, 'rowsEnd');
			break;

		case 'type6':

			// Set some CSS related style values
			grid.style.setProperty('--perspective', '2500px');
			grid.style.setProperty('--grid-width', '100%');
			grid.style.setProperty('--grid-gap', '6');
			grid.style.setProperty('--grid-columns', '3');
			grid.style.setProperty('--grid-item-ratio', '1');
			
			timeline
			.fromTo(gridItems, {
				transformOrigin: '50% 200%',
				rotationX: 0,
				yPercent: 400,
			}, {
				yPercent: 0,
				rotationY: 360,
				opacity: 0.2,
				scale: 0.8,
				stagger: 0.03,
			})

			break;
	  	
		default:
			console.error('Unknown animation type.');
			break;
	}
}

// Apply animations to each grid
const scroll = () => {
	grids.forEach((grid, i) => {
		// Determine animation type
		let animationType;
		switch (i % 6) {
			case 0:
				animationType = 'type1';
				break;
			case 1:
				animationType = 'type2';
				break;
			case 2:
				animationType = 'type3';
				break;
			case 3:
				animationType = 'type4';
				break;
			case 4:
				animationType = 'type5';
				break;
			case 5:
				animationType = 'type6';
				break;
		}
		applyAnimation(grid, animationType);
	});
}

// Preload images, initialize smooth scrolling, apply scroll-triggered animations, and remove loading class from body
preloadImages('.grid__item-inner').then(() => {
	initSmoothScrolling();
	scroll();
	document.body.classList.remove('loading');
});



// ====================================================================================================================================
//  Navbar Animations | www.codrops.com | MIT License --------------------------------------------
{
	setTimeout(() => document.body.classList.add('render'), 60);
	const navdemos = Array.from(document.querySelectorAll('nav.demos > .demo'));
	const total = navdemos.length;
	const current = navdemos.findIndex(el => el.classList.contains('demo--current'));
	const navigate = (linkEl) => {
		document.body.classList.remove('render');
		document.body.addEventListener('transitionend', () => window.location = linkEl.href);
	};
	navdemos.forEach(link => link.addEventListener('click', (ev) => {
		ev.preventDefault();
		navigate(ev.target);
	}));
	document.addEventListener('keydown', (ev) => {
		const keyCode = ev.keyCode || ev.which;
		let linkEl;
		if ( keyCode === 37 ) {
			linkEl = current > 0 ? navdemos[current-1] : navdemos[total-1];
		}
		else if ( keyCode === 39 ) {
			linkEl = current < total-1 ? navdemos[current+1] : navdemos[0];
		}
		else {
			return false;
		}
		navigate(linkEl);
	});
};

class ShapeOverlays {
	constructor(elm) {
	  this.elm = elm;
	  this.path = elm.querySelectorAll('path');
	  this.numPoints = 18;
	  this.duration = 600;
	  this.delayPointsArray = [];
	  this.delayPointsMax = 300;
	  this.delayPerPath = 100;
	  this.timeStart = Date.now();
	  this.isOpened = false;
	  this.isAnimating = false;
	}
	toggle() {
	  this.isAnimating = true;
	  const range = 4 * Math.random() + 6;
	  for (var i = 0; i < this.numPoints; i++) {
		const radian = i / (this.numPoints - 1) * Math.PI;
		this.delayPointsArray[i] = (Math.sin(-radian) + Math.sin(-radian * range) + 2) / 4 * this.delayPointsMax;
	  }
	  if (this.isOpened === false) {
		this.open();
	  } else {
		this.close();
	  }
	}
	open() {
	  this.isOpened = true;
	  this.elm.classList.add('is-opened');
	  this.timeStart = Date.now();
	  this.renderLoop();
	}
	close() {
	  this.isOpened = false;
	  this.elm.classList.remove('is-opened');
	  this.timeStart = Date.now();
	  this.renderLoop();
	}
	updatePath(time) {
	  const points = [];
	  for (var i = 0; i < this.numPoints + 1; i++) {
		points[i] = ease.cubicInOut(Math.min(Math.max(time - this.delayPointsArray[i], 0) / this.duration, 1)) * 100
	  }
  
	  let str = '';
	  str += (this.isOpened) ? `M 0 0 V ${points[0]} ` : `M 0 ${points[0]} `;
	  for (var i = 0; i < this.numPoints - 1; i++) {
		const p = (i + 1) / (this.numPoints - 1) * 100;
		const cp = p - (1 / (this.numPoints - 1) * 100) / 2;
		str += `C ${cp} ${points[i]} ${cp} ${points[i + 1]} ${p} ${points[i + 1]} `;
	  }
	  str += (this.isOpened) ? `V 0 H 0` : `V 100 H 0`;
	  return str;
	}
	render() {
	  if (this.isOpened) {
		for (var i = 0; i < this.path.length; i++) {
		  this.path[i].setAttribute('d', this.updatePath(Date.now() - (this.timeStart + this.delayPerPath * i)));
		}
	  } else {
		for (var i = 0; i < this.path.length; i++) {
		  this.path[i].setAttribute('d', this.updatePath(Date.now() - (this.timeStart + this.delayPerPath * (this.path.length - i - 1))));
		}
	  }
	}
	renderLoop() {
	  this.render();
	  if (Date.now() - this.timeStart < this.duration + this.delayPerPath * (this.path.length - 1) + this.delayPointsMax) {
		requestAnimationFrame(() => {
		  this.renderLoop();
		});
	  }
	  else {
		this.isAnimating = false;
	  }
	}
  }
//   ---------------------------------------------------------------
  
  (function() {
	const elmHamburger = document.querySelector('.hamburger');
	const gNavItems = document.querySelectorAll('.global-menu__item');
	const elmOverlay = document.querySelector('.shape-overlays');
	const overlay = new ShapeOverlays(elmOverlay);
  
	elmHamburger.addEventListener('click', () => {
	  if (overlay.isAnimating) {
		return false;
	  }
	  overlay.toggle();
	  if (overlay.isOpened === true) {
		elmHamburger.classList.add('is-opened-navi');
		for (var i = 0; i < gNavItems.length; i++) {
		  gNavItems[i].classList.add('is-opened');
		}
	  } else {
		elmHamburger.classList.remove('is-opened-navi');
		for (var i = 0; i < gNavItems.length; i++) {
		  gNavItems[i].classList.remove('is-opened');
		}
	  }
	});
  }());
//   -------------------------------------------------
// these easing functions are based on the code of glsl-easing module.
// https://github.com/glslify/glsl-easings
//

const ease = {
	exponentialIn: (t) => {
	  return t == 0.0 ? t : Math.pow(2.0, 10.0 * (t - 1.0));
	},
	exponentialOut: (t) => {
	  return t == 1.0 ? t : 1.0 - Math.pow(2.0, -10.0 * t);
	},
	exponentialInOut: (t) => {
	  return t == 0.0 || t == 1.0
		? t
		: t < 0.5
		  ? +0.5 * Math.pow(2.0, (20.0 * t) - 10.0)
		  : -0.5 * Math.pow(2.0, 10.0 - (t * 20.0)) + 1.0;
	},
	sineOut: (t) => {
	  const HALF_PI = 1.5707963267948966;
	  return Math.sin(t * HALF_PI);
	},
	circularInOut: (t) => {
	  return t < 0.5
		  ? 0.5 * (1.0 - Math.sqrt(1.0 - 4.0 * t * t))
		  : 0.5 * (Math.sqrt((3.0 - 2.0 * t) * (2.0 * t - 1.0)) + 1.0);
	},
	cubicIn: (t) => {
	  return t * t * t;
	},
	cubicOut: (t) => {
	  const f = t - 1.0;
	  return f * f * f + 1.0;
	},
	cubicInOut: (t) => {
	  return t < 0.5
		? 4.0 * t * t * t
		: 0.5 * Math.pow(2.0 * t - 2.0, 3.0) + 1.0;
	},
	quadraticOut: (t) => {
	  return -t * (t - 2.0);
	},
	quarticOut: (t) => {
	  return Math.pow(t - 1.0, 3.0) * (1.0 - t) + 1.0;
	},
  };
// ====================================================================================================================================












// Second GRID ================================================================================================================================


  
  // Function to animate the First grid
  const animateFirstGrid = () => {
	const grid = document.querySelector('[data-grid-first]');
	const gridImages = grid.querySelectorAll('.grid__img');
	
	gsap.timeline({
	  defaults: {
		ease: 'none'
	  },
	  scrollTrigger: {
		trigger: grid,
		start: 'center center',
		end: '+=200%',
		pin: grid.parentNode,
		scrub: 0.5,
	  }
	})
	.from(gridImages, {
	  stagger: {
		amount: 0.03,
		from: 'edges',
		grid: [3,3]
	  },
	  scale: 0.7,
	  autoAlpha: 0
	})
	.from(grid, {
	  scale: .7,
	  skewY: 5,
	}, 0);
  };
  
  
  // Main initialization function
  const init = () => {
  
	// Call animations for each grid based on their data attributes
	animateFirstGrid();
  };
  // Preload images and initialize animations
  preloadImages('.grid__img').then(() => {
	init();
	window.scrollTo(0, 0);
  });



  // ===================================================================================================================================

const portfolioLightbox = GLightbox({
    selector: '.portfolio-lightbox'
});